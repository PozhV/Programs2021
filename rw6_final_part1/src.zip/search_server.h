/*
 * search_server.h
 *
 *  Created on: 26 ���. 2021 �.
 *      Author: User
 */

#ifndef SEARCH_SERVER_H_
#define SEARCH_SERVER_H_
#pragma once
#include "profile.h"
#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <unordered_map>
#include <string>
#include<string_view>
using namespace std;

class InvertedIndex {
public:
  void Add(const string& document);
  vector<pair<size_t,size_t>> Lookup(const string& word) const;

  /*/string_view GetDocument(size_t id) const {
	string_view sv(docs[id]);
    return sv;
  }/*/

private:
  map<string, vector<pair<size_t,size_t>>> index;
  size_t last_docid = 0;
};

class SearchServer {
public:
  SearchServer() = default;
  explicit SearchServer(istream& document_input);//, TotalDuration& dur);
  void UpdateDocumentBase(istream& document_input);//, TotalDuration& dur);
  void AddQueriesStream(istream& query_input, ostream& search_results_output);
  void UpdateDocumentBase(istream& document_input, TotalDuration& dur);
  void AddQueriesStream(istream& query_input, ostream& search_results_output, TotalDuration& dur);

private:
  InvertedIndex index;
};





#endif /* SEARCH_SERVER_H_ */
