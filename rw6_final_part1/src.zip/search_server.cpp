/*
 * search_server.cpp
 *
 *  Created on: 26 ���. 2021 �.
 *      Author: User
 */
#include "search_server.h"
#include "iterator_range.h"
#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
using namespace std;
void Print(const array<pair<size_t, size_t>, 5>& docid)
{
	for(int i = 0; i < 5; i++)
		cout<< docid[i].second << ";"<< docid[i].first << " ";
	cout<<endl;
}
void Print_(const map<string, vector<pair<size_t, size_t>>>& index)
{
	for(const auto& [word, vec] : index)
	{
		cout<<word<<" : "<<endl;
		for(const auto& p: vec)
		{
			cout<<p.first<<" "<<p.second<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
}
vector<string> SplitIntoWords(const string& line) {
  istringstream words_input(line);
  return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
  UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
  InvertedIndex new_index;
  //ADD_DURATION(dur);
  for (string current_document; getline(document_input, current_document); ) {
	  //<<current_document<<endl;
    new_index.Add(move(current_document));
  }

  index = move(new_index);

}

void SearchServer::AddQueriesStream(istream& query_input, ostream& search_results_output) {
	for (string current_query; getline(query_input, current_query); ) {
	    const auto words = SplitIntoWords(current_query);
	    size_t ind_max = 0;
	    vector<size_t> docid_count(50000, 0);
	    for (const auto& word : words) {
	    	//cout<<word<<endl;
	    	for (const auto &p : index.Lookup(word)) {
	        docid_count[p.first] += p.second;
	        ind_max = max(p.first, ind_max);
	      }
	    }
	    //cout<<ind_max<<endl;
	    //vector<pair<size_t, size_t>> search_results(
	      //docid_count.begin(), docid_count.end()
	    //);
	    array<size_t, 5> search_results = {0, 0, 0, 0, 0};
	    array<size_t, 5> index_results = {0, 0, 0, 0, 0};
	    for(size_t i = 0; i <= ind_max; i++)
	    {
	    	if(docid_count[i] > search_results[4]){
	    		search_results[4] = docid_count[i];
	    		index_results[4] = i;
	    		int j = 3;
	    		while( search_results[j+1] > search_results[j])
	    		{

	    			swap(search_results[j+1], search_results[j]);
	    			swap(index_results[j+1], index_results[j]);
	    			if(j == 0) break;
	    			j--;
	    		}
	    	}
	    }
	    search_results_output << current_query << ':';
	    for (int i = 0; i < 5; i++) {
	    	if(search_results[i] > 0){
	    	search_results_output << " {"
	        << "docid: " << index_results[i] << ", "
	        << "hitcount: " << search_results[i] << '}';
	    	}
	    }
	    search_results_output<<endl;
	  }
}
void SearchServer::UpdateDocumentBase(istream& document_input, TotalDuration& dur) {
  InvertedIndex new_index;
  ADD_DURATION(dur);
  for (string current_document; getline(document_input, current_document); ) {
    new_index.Add(move(current_document));
  }

  index = move(new_index);

}

void SearchServer::AddQueriesStream(istream& query_input, ostream& search_results_output, TotalDuration& dur) {
	ADD_DURATION(dur);
  for (string current_query; getline(query_input, current_query); ) {
    const auto words = SplitIntoWords(current_query);
    size_t ind_max = 0;
    vector<size_t> docid_count(50000, 0);
    for (const auto& word : words) {
    	//cout<<word<<endl;
    	for (const auto &p : index.Lookup(word)) {
        docid_count[p.first] += p.second;
        ind_max = max(p.first, ind_max);
      }
    }
    //cout<<ind_max<<endl;
    //vector<pair<size_t, size_t>> search_results(
      //docid_count.begin(), docid_count.end()
    //);
    array<size_t, 5> search_results = {0, 0, 0, 0, 0};
    array<size_t, 5> index_results = {0, 0, 0, 0, 0};
    for(size_t i = 0; i <= ind_max; i++)
    {
    	if(docid_count[i] > search_results[4]){
    		search_results[4] = docid_count[i];
    		index_results[4] = i;
    		int j = 3;
    		while( search_results[j+1] > search_results[j])
    		{

    			swap(search_results[j+1], search_results[j]);
    			swap(index_results[j+1], index_results[j]);
    			if(j == 0) break;
    			j--;
    		}
    	}
    }
    search_results_output << current_query << ':';
    for (int i = 0; i < 5; i++) {
    	if(search_results[i] > 0){
    	search_results_output << " {"
        << "docid: " << index_results[i] << ", "
        << "hitcount: " << search_results[i] << '}';
    	}
    }
    search_results_output<<endl;
  }
}

void InvertedIndex::Add(const string& document) {
  for (auto& word : SplitIntoWords(document)) {
	  auto it = index.find(word);
	  if(it != index.end())
	  {
		  auto it1 = prev(it->second.end());
		  if(it1->first != last_docid)
			it->second.push_back(make_pair(last_docid, 1));
		  else
			it1->second++;
		  }
	  else
	  {
		  index[move(word)].push_back(make_pair(last_docid, 1));
	  }
  }
  //cout<<last_docid<<endl;
  //Print_(index);
  last_docid++;
}

vector<pair<size_t, size_t>> InvertedIndex::Lookup(const string& word) const {
  if (auto it = index.find(word); it != index.end()) {
    return it->second;
  } else {
    return {};
  }
}



